OpenGIS(r) Sampling 1.0.0 - ReadMe.txt

Observations and Measurements - Part 2 - Sampling Features (OGC 07-002r3)

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2007 Open Geospatial Consortium, Inc. All Rights Reserved.
