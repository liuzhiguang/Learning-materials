OpenGIS(r) O&M 1.0.0 - ReadMe.txt

GML Application Schema version of the O&M 1.0.0 model. (OGC 07-022r1)

The general models and XML encodings for observations and measurements,
including but not restricted to those using sensors.  The Observations and
Measurements schema are defined in the OGC document 07-022r1.

2007-10-05  Simon Cox

  * Published om/1.0.0 schemas from 07-022r1

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2007 Open Geospatial Consortium, Inc. All Rights Reserved.
